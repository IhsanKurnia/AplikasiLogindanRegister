<?php

include 'connection.php';

if($_POST){
    // POST DATA
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);

    $response = [];

    // Chek username didalam database
    $userQuery = $connection->prepare("SELECT * FROM user where username = ?");
    $userQuery->execute(array($username));
    
    // Cek username
    if($userQuery->rowCount() !=0){
        // Beri response
        $response['status'] = false;
        $response['message'] = 'Akun Sudah Digunakan';
    }else{
        $insertAccount = 'INSERT INTO user (username, password, name) values (:username, :password, :name)';
        $statement = $connection->prepare($insertAccount);

        try{
            // Eksekusi Statetement db
            $statement->execute([
                ':username' => $username,
                ':password' => md5($password),
                ':name' => $name
            ]);

            // Beri response
            $response['status'] = true;
            $response['message'] = 'Akun berhasil didaftar';
            $response['data'] =[
                'username' => $username,
                'name' => $name
            ];
        }catch (Exception $e){
            die($e->getMessage());
        }
    }

    // JSON
    $json = json_encode($response, JSON_PRETTY_PRINT);

    // print JSON
    echo $json;
}
?>